import React from 'react'

const Products = () => {
  return (
    <>
    
    Products
    
    </>
  )
}

export default Products